<?php

$string['pluginname'] = 'Foo';
