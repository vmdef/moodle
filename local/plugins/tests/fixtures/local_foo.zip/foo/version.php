<?php

$plugin->component = 'local_foo';
$plugin->version = 2021052800;
$plugin->requires = 2020061500;
