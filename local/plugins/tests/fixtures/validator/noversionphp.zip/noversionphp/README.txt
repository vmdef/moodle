This plugin does not have version.php file
