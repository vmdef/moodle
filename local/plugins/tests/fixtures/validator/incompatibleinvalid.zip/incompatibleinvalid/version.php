<?php

$plugin->requires = 2019111800;

// This is invalid syntax.
$plugin->incompatible = '3.11';
