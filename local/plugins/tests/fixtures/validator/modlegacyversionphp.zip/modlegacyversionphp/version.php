<?php

// This activity module is using legacy notation

$module->version = 2010010100;
