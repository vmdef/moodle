<?php

// This plugin does not provide expected information

$version = 2010010100;
