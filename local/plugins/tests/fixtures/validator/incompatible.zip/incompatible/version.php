<?php

// Just a bit higher than 3.8.
$plugin->requires = 2019111800.01;

// Moodle 3.10 and higher will be prevented from installing the plugin.
$plugin->incompatible = 310;
