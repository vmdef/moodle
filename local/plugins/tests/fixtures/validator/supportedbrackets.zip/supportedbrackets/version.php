<?php

// Moodle 3.9.1.
$plugin->requires = 2020061501;

// But really only 3.9 and 3.10 because 3.8 is lower than required.
$plugin->supported = [
    38,
    310,
];
