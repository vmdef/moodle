<?php

$plugin->version = 2021060800;
$plugin->requires = 2020061500;
