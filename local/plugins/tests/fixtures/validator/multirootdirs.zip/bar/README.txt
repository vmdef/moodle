Valid archive contains just one root directory.
