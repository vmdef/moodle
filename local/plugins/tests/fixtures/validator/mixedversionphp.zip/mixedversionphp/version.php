<?php

// This activity module is using both legacy and new notation

$module->version = 2010010100;
$plugin->version = 2010010100;
