<?php

// Claim support for everything from 3.9
$plugin->supported = [39, 999];

// But incompatible starting from 4.0.
$pluging->incompatible = 400;
