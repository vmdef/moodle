<?php

// This plugin declares its component explicitly
// Example: $plugin->component = 'foo_something_else';

$plugin->requires = 2015011501.00;
$plugin->component = 'foo_barbaz';
