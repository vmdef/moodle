<?php

// This plugin specifies too low version number by mistake.

$plugin->requires = 202061401;
