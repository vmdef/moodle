<?php

// This activity module is using new notation

$plugin->version = 2010010100;
