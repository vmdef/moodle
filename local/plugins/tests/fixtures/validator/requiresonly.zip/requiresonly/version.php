<?php

// This plugin only specifies the required Moodle version.

$plugin->requires = 2020061401;
