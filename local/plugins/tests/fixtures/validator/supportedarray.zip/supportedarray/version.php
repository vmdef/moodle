<?php

$plugin->supported = array(37, 39);
