<?php

$string['pluginname'] = 'Bar';
