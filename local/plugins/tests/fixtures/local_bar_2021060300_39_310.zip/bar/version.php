<?php

$plugin->component = 'local_bar';
$plugin->version = 2021060300;
$plugin->supported = [39, 310];
