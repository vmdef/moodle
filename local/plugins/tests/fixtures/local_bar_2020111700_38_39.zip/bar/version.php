<?php

$plugin->component = 'local_bar';
$plugin->version = 2020111700;
$plugin->supported = [38, 39];
